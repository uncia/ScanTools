# WinPcap_Install
Auto install WinPcap on Windows(command line)

Reverse the installation of WinPcap and use the Install_WinPcap.bat to achieve the same goal.

Author: 3gstudent@3gstudent

License: BSD 3-Clause

- Need Administrator permission
- Support x86 and x64
- Use to start masscan or nmap on Windows System. Maybe other tools need more files of WinPcap.

Details：

https://3gstudent.github.io/3gstudent.github.io/%E6%B8%97%E9%80%8F%E6%8A%80%E5%B7%A7-Windows%E5%B9%B3%E5%8F%B0%E8%BF%90%E8%A1%8CMasscan%E5%92%8CNmap/
